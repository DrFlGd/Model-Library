Printed at 0.2 mm.
